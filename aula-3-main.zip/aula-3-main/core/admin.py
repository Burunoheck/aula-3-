from django.contrib import admin

from core.models import Categoria, Marca

admin.site.register(Marca)
admin.site.register(Categoria)
